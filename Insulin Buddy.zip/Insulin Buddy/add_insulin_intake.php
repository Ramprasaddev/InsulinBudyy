<?php
include 'config.php';

// Decode JSON input
$data = json_decode(file_get_contents("php://input"));

// Validation
if (!isset($data->username) || !isset($data->intake_value)) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit;
}

$username = $data->username;
$intake_value = $data->intake_value;
$note = $data->note ?? "";

// Insert into insulin table
$stmt = $conn->prepare("INSERT INTO insulin_intake (username, intake_value, note) VALUES (?, ?, ?)");
$stmt->bind_param("sds", $username, $intake_value, $note);

if ($stmt->execute()) {


    echo json_encode(["status" => "success", "message" => "Insulin intake recorded"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to insert insulin data"]);
}

$stmt->close();
$conn->close();
?>
