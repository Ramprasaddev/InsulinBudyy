<?php
header('Content-Type: application/json; charset=utf-8');
include 'config.php';

$username   = $_GET['username'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date   = $_GET['end_date'] ?? '';

if (empty($username) || empty($start_date) || empty($end_date)) {
    http_response_code(400);
    echo json_encode(["error" => "Missing username or start_date or end_date"], JSON_PRETTY_PRINT);
    exit;
}

$start_datetime = date('Y-m-d 00:00:00', strtotime($start_date));
$end_datetime   = date('Y-m-d 23:59:59', strtotime($end_date));

$query = "SELECT 
            intake_time, 
            intake_value,
            DATE(intake_time) AS only_date,
            CASE
                WHEN TIME(intake_time) BETWEEN '05:00:00' AND '11:59:59' THEN 'Morning'
                WHEN TIME(intake_time) BETWEEN '12:00:00' AND '17:59:59' THEN 'Afternoon'
                ELSE 'Night'
            END AS session
          FROM insulin_intake
          WHERE username = ?
            AND intake_time BETWEEN ? AND ?
          ORDER BY intake_time ASC";

$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $username, $start_datetime, $end_datetime);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [
        "date"    => $row['intake_time'],
        "session" => $row['session'],
        "value"   => floatval($row['intake_value'])
    ];
}

// Lifetime average
$lifetimeAvgQuery = "SELECT AVG(intake_value) AS avg_value FROM insulin_intake WHERE username = ?";
$stmt2 = $conn->prepare($lifetimeAvgQuery);
$stmt2->bind_param("s", $username);
$stmt2->execute();
$lifetimeAvg = $stmt2->get_result()->fetch_assoc()['avg_value'] ?? 0;

// Last 7 days average
$sevenDaysStart = date('Y-m-d 00:00:00', strtotime('-6 days'));
$sevenDaysEnd   = date('Y-m-d 23:59:59');
$sevenDaysAvgQuery = "SELECT AVG(intake_value) AS avg_value 
                      FROM insulin_intake 
                      WHERE username = ? 
                      AND intake_time BETWEEN ? AND ?";
$stmt3 = $conn->prepare($sevenDaysAvgQuery);
$stmt3->bind_param("sss", $username, $sevenDaysStart, $sevenDaysEnd);
$stmt3->execute();
$sevenDaysAvg = $stmt3->get_result()->fetch_assoc()['avg_value'] ?? 0;

// Selected period average
$selectedAvg = array_sum(array_column($data, 'value')) / max(count($data), 1);

echo json_encode([
    "stats" => [
        "lifetime_avg" => round($lifetimeAvg, 1),
        "last7days_avg" => round($sevenDaysAvg, 1),
        "selected_avg" => round($selectedAvg, 1)
    ],
    "data" => $data
], JSON_PRETTY_PRINT);
?>