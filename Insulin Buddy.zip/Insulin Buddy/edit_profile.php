<?php
header("Content-Type: application/json");

// DB config
$host = "localhost";
$dbname = "insulinbuddy";
$db_user = "root";
$db_pass = "123456";

// Connect to DB
$conn = new mysqli($host, $db_user, $db_pass, $dbname);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit();
}

// Get POST data
$username = $_POST['username'] ?? '';
$contact = $_POST['contact'] ?? '';
$age = (int)($_POST['age'] ?? 0);
$isf = (float)($_POST['isf'] ?? 0);
$icr = (float)($_POST['icr'] ?? 0);
$target = (float)($_POST['target'] ?? 0);
$weight = (float)($_POST['weight'] ?? 0);

if (!$username) {
    echo json_encode(["status" => "error", "message" => "Username is required"]);
    exit();
}

// Prepare and execute update
$sql = "UPDATE user_profile SET contact = ?, age = ?,  isf = ?, icr = ?, target = ?, weight = ? WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sisddds", $contact, $age, $isf, $icr, $target, $weight, $username);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Profile updated successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to update profile"]);
}

$stmt->close();
$conn->close();
?>
