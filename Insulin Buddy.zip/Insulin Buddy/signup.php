<?php
header("Content-Type: application/json");

// Database credentials
$host = "localhost";
$dbname = "insulinbuddy";
$username = "root";
$password = "123456"; // your DB password

// Connect to MySQL
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit();
}

// Read JSON input
$input = json_decode(file_get_contents("php://input"), true);

// Validate required fields
$required = ["full_name", "username", "email", "password"];
foreach ($required as $field) {
    if (empty($input[$field])) {
        echo json_encode(["status" => "error", "message" => "Missing field: $field"]);
        exit();
    }
}

// Clean inputs
$full_name = trim($input['full_name']);
$user_name = trim($input['username']);
$email = trim($input['email']);
$raw_password = trim($input['password']);
$pass = password_hash($raw_password, PASSWORD_DEFAULT);

// ✅ Validation Rules
// Username: 4–15 alphabetic (A–Z, a–z)
if (!preg_match('/^[a-zA-Z]{4,15}$/', $user_name)) {
    echo json_encode([
        "status" => "error",
        "message" => "Username must be 4 to 15 alphabetic characters only"
    ]);
    exit();
}

// Full name: letters and spaces only
if (!preg_match("/^[a-zA-Z ]{3,40}$/", $full_name)) {
    echo json_encode([
        "status" => "error",
        "message" => "Full name should contain only letters and spaces (3–40 chars)"
    ]);
    exit();
}

// Email format check
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid email format"
    ]);
    exit();
}

// Password strength check
if (!preg_match('/^(?=.*[A-Z])(?=.*[0-9])(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $raw_password)) {
    echo json_encode([
        "status" => "error",
        "message" => "Password must be at least 8 chars, include 1 uppercase, 1 number, and 1 special character"
    ]);
    exit();
}

// Check for existing username (case-insensitive)
$checkUserSql = "SELECT id FROM users WHERE LOWER(username) = LOWER(?)";
$checkUserStmt = $conn->prepare($checkUserSql);
$checkUserStmt->bind_param("s", $user_name);
$checkUserStmt->execute();
$checkUserStmt->store_result();

if ($checkUserStmt->num_rows > 0) {
    echo json_encode([
        "status" => "error",
        "message" => "Username already exists"
    ]);
    $checkUserStmt->close();
    $conn->close();
    exit();
}
$checkUserStmt->close();

// Check for existing email
$checkEmailSql = "SELECT id FROM users WHERE LOWER(email) = LOWER(?)";
$checkEmailStmt = $conn->prepare($checkEmailSql);
$checkEmailStmt->bind_param("s", $email);
$checkEmailStmt->execute();
$checkEmailStmt->store_result();

if ($checkEmailStmt->num_rows > 0) {
    echo json_encode([
        "status" => "error",
        "message" => "Email already registered"
    ]);
    $checkEmailStmt->close();
    $conn->close();
    exit();
}
$checkEmailStmt->close();

// Insert new user record
$insertSql = "INSERT INTO users (username, full_name, email, password) VALUES (?, ?, ?, ?)";
$insertStmt = $conn->prepare($insertSql);
$insertStmt->bind_param("ssss", $user_name, $full_name, $email, $pass);

if ($insertStmt->execute()) {
    echo json_encode([
        "status" => "success",
        "message" => "User registered successfully"
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Registration failed",
        "error" => $insertStmt->error
    ]);
}

$insertStmt->close();
$conn->close();
?>
