<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

include 'config.php'; // your db connection file

// Read JSON input
$data = json_decode(file_get_contents("php://input"));

if (!$data || !isset($data->username) || !isset($data->password)) {
    echo json_encode(["status" => "fail", "message" => "Missing username or password"]);
    exit;
}

$username = mysqli_real_escape_string($conn, $data->username);
$password = $data->password;

// Fetch hashed password from `users` table
$stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo json_encode(["status" => "fail", "message" => "User not found"]);
    $stmt->close();
    $conn->close();
    exit;
}

$user = $result->fetch_assoc();
$stmt->close();

if (!password_verify($password, $user["password"])) {
    echo json_encode(["status" => "fail", "message" => "Incorrect password"]);
    $conn->close();
    exit;
}

// Check profile completeness from `user_profile` table
$stmt2 = $conn->prepare("SELECT isf, weight FROM user_profile WHERE username = ?");
$stmt2->bind_param("s", $username);
$stmt2->execute();
$result2 = $stmt2->get_result();

$isProfileComplete = false;

if ($result2->num_rows === 1) {
    $profile = $result2->fetch_assoc();
    $isProfileComplete = !empty($profile["isf"]) && !empty($profile["weight"]);
}
$stmt2->close();
$conn->close();

// Final response
echo json_encode([
    "status" => "success",
    "message" => "Login successful",
    "is_profile_complete" => $isProfileComplete
]);
