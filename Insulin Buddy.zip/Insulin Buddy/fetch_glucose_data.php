<?php
header('Content-Type: application/json; charset=utf-8');
include 'config.php';

$username   = $_GET['username'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date   = $_GET['end_date'] ?? '';

if (empty($username) || empty($start_date) || empty($end_date)) {
    http_response_code(400);
    echo json_encode(["error" => "Missing username or start_date or end_date"], JSON_PRETTY_PRINT);
    exit;
}

$start_datetime = date('Y-m-d 00:00:00', strtotime($start_date));
$end_datetime   = date('Y-m-d 23:59:59', strtotime($end_date));

$query = "SELECT 
            recorded_time, 
            glucose_value,
            DATE(recorded_time) AS only_date,
            CASE
                WHEN TIME(recorded_time) BETWEEN '05:00:00' AND '11:59:59' THEN 'Morning'
                WHEN TIME(recorded_time) BETWEEN '12:00:00' AND '17:59:59' THEN 'Afternoon'
                ELSE 'Night'
            END AS session
          FROM glucose_level
          WHERE username = ?
            AND recorded_time BETWEEN ? AND ?
          ORDER BY recorded_time ASC";

$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $username, $start_datetime, $end_datetime);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [
        "date"    => $row['only_date'],
        "session" => $row['session'],
        "value"   => floatval($row['glucose_value'])
    ];
}

// Lifetime average
$lifetimeAvgQuery = "SELECT AVG(glucose_value) AS avg_value FROM glucose_level WHERE username = ?";
$stmt2 = $conn->prepare($lifetimeAvgQuery);
$stmt2->bind_param("s", $username);
$stmt2->execute();
$lifetimeAvg = $stmt2->get_result()->fetch_assoc()['avg_value'] ?? 0;

// Last 7 days average
$sevenDaysStart = date('Y-m-d 00:00:00', strtotime('-6 days'));
$sevenDaysEnd   = date('Y-m-d 23:59:59');
$sevenDaysAvgQuery = "SELECT AVG(glucose_value) AS avg_value 
                      FROM glucose_level 
                      WHERE username = ? 
                      AND recorded_time BETWEEN ? AND ?";
$stmt3 = $conn->prepare($sevenDaysAvgQuery);
$stmt3->bind_param("sss", $username, $sevenDaysStart, $sevenDaysEnd);
$stmt3->execute();
$sevenDaysAvg = $stmt3->get_result()->fetch_assoc()['avg_value'] ?? 0;

// Selected period average
$selectedAvg = array_sum(array_column($data, 'value')) / max(count($data), 1);

echo json_encode([
    "stats" => [
        "lifetime_avg" => round($lifetimeAvg, 2),
        "last7days_avg" => round($sevenDaysAvg, 2),
        "selected_avg" => round($selectedAvg, 2)
    ],
    "data" => $data
], JSON_PRETTY_PRINT);
?>
