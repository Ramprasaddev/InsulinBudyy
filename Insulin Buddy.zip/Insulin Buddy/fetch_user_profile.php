<?php
// fetch_user_profile.php

header('Content-Type: application/json');
require_once 'config.php';

// Check if username is provided in the URL query parameter
if (!isset($_GET['username']) || empty($_GET['username'])) {
    echo json_encode(['error' => 'Username not provided']);
    exit;
}

$username = $_GET['username'];

// Use the $conn object from config.php
if (!$conn) {
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// Prepare the SQL statement to prevent SQL injection
// Note: We use the same column aliases for consistent JSON output
$stmt = $conn->prepare('SELECT gender, age, isf AS ISR, icr AS ICR, target AS target_glucose, type_of_diabetes FROM user_profile WHERE username = ?');

// Check if the statement was prepared successfully
if ($stmt === false) {
    echo json_encode(['error' => 'Failed to prepare statement: ' . $conn->error]);
    exit;
}

// Bind the username parameter
$stmt->bind_param('s', $username);

// Execute the statement
$stmt->execute();

// Get the result set
$result = $stmt->get_result();
$profile = $result->fetch_assoc();

if ($profile) {
    echo json_encode($profile);
} else {
    echo json_encode(['error' => 'User not found']);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>