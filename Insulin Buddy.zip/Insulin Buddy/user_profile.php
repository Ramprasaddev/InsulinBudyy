<?php
declare(strict_types=1);
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST");

error_reporting(0);
ini_set('display_errors', '0');

$host = "localhost";
$dbname = "insulinbuddy";
$db_user = "root";
$db_pass = "123456";

$conn = new mysqli($host, $db_user, $db_pass, $dbname);
if ($conn->connect_error) {
    http_response_code(200);
    echo json_encode(["status" => "error", "message" => "DB connection failed"]);
    exit;
}
$conn->set_charset("utf8mb4");

// Read input from both JSON and x-www-form-urlencoded
$raw = file_get_contents("php://input");
$in = json_decode($raw, true) ?? [];

// Merge fallback $_POST for Volley form data
$username          = $in['username'] ?? ($_POST['username'] ?? null);
$contact           = $in['contact'] ?? ($_POST['contact'] ?? null);
$age               = isset($in['age']) ? (int)$in['age'] : (isset($_POST['age']) ? (int)$_POST['age'] : null);
$gender            = $in['gender'] ?? ($_POST['gender'] ?? null);
$isf               = isset($in['isf']) ? (float)$in['isf'] : (isset($_POST['isf']) ? (float)$_POST['isf'] : null);
$icr               = isset($in['icr']) ? (float)$in['icr'] : (isset($_POST['icr']) ? (float)$_POST['icr'] : null);
$target            = isset($in['target']) ? (float)$in['target'] : (isset($_POST['target']) ? (float)$_POST['target'] : null);
$weight            = isset($in['weight']) ? (float)$in['weight'] : (isset($_POST['weight']) ? (float)$_POST['weight'] : null);
$type_of_diabetes  = $in['type_of_diabetes'] ?? ($_POST['type_of_diabetes'] ?? null);
$diagnosis_year    = isset($in['diagnosis_year']) ? (int)$in['diagnosis_year'] : (isset($_POST['diagnosis_year']) ? (int)$_POST['diagnosis_year'] : null);
$diet_type         = $in['diet_type'] ?? ($_POST['diet_type'] ?? null);

// ✅ Added dual-source profile_completed field
$profile_completed = isset($in['profile_completed']) 
    ? (int)$in['profile_completed'] 
    : (isset($_POST['profile_completed']) ? (int)$_POST['profile_completed'] : 0);

if (!$username || !$contact) {
    echo json_encode(["status" => "error", "message" => "Username and contact required"]);
    exit;
}

// SQL upsert
$sql = "INSERT INTO `user_profile`
(`username`,`contact`,`age`,`gender`,`isf`,`icr`,`target`,`weight`,`type_of_diabetes`,`diagnosis_year`,`diet_type`,`profile_completed`)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
ON DUPLICATE KEY UPDATE
`contact`=VALUES(`contact`),
`age`=VALUES(`age`),
`gender`=VALUES(`gender`),
`isf`=VALUES(`isf`),
`icr`=VALUES(`icr`),
`target`=VALUES(`target`),
`weight`=VALUES(`weight`),
`type_of_diabetes`=VALUES(`type_of_diabetes`),
`diagnosis_year`=VALUES(`diagnosis_year`),
`diet_type`=VALUES(`diet_type`),
`profile_completed`=VALUES(`profile_completed`)";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Prepare failed"]);
    exit;
}

$stmt->bind_param(
    "ssisddddsisi",
    $username,
    $contact,
    $age,
    $gender,
    $isf,
    $icr,
    $target,
    $weight,
    $type_of_diabetes,
    $diagnosis_year,
    $diet_type,
    $profile_completed
);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Profile saved successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to save profile"]);
}

$stmt->close();
$conn->close();
