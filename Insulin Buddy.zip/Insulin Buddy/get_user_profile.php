<?php
header("Content-Type: application/json");
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database config
$host = "localhost";
$dbname = "insulinbuddy";
$db_user = "root";
$db_pass = "123456";

// Connect to DB
$conn = new mysqli($host, $db_user, $db_pass, $dbname);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Read input (JSON or form)
$rawInput = file_get_contents("php://input");
$input = json_decode($rawInput, true);
$username = "";

if (isset($input['username']) && !empty($input['username'])) {
    $username = $input['username'];
} elseif (isset($_POST['username']) && !empty($_POST['username'])) {
    $username = $_POST['username'];
} else {
    echo json_encode(["status" => "error", "message" => "Username required"]);
    exit();
}

// ✅ Match your actual DB column names
$sql = "SELECT gender, age, type_of_diabetes, icr, isf, target 
        FROM user_profile 
        WHERE username = ?";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Query preparation failed: " . $conn->error]);
    exit();
}

$stmt->bind_param("s", $username);
$stmt->execute();

// Bind results using correct variable names
$stmt->bind_result($gender, $age, $type_of_diabetes, $icr, $isf, $target);

if ($stmt->fetch()) {
    // Normalize gender
    $gender = strtolower(trim($gender));
    $gender = in_array($gender, ['f', 'female', 'woman']) ? 'Female' : 'Male';

    // Normalize diabetes type
    $dtype = strtolower(str_replace(' ', '', $type_of_diabetes));
    if (in_array($dtype, ['type1', 't1', 'type_1'])) $dtype = 'Type1';
    else if (in_array($dtype, ['type2', 't2', 'type_2'])) $dtype = 'Type2';
    else $dtype = null;

    echo json_encode([
        "status" => "success",
        "gender" => $gender,
        "age" => intval($age),
        "diabetes_type" => $dtype,
        "icr" => floatval($icr),
        // ✅ Return as "isr" and "target_glucose" to match Android / API expectation
        "isr" => floatval($isf),
        "target_glucose" => floatval($target)
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "User not found"]);
}

$stmt->close();
$conn->close();
?>
