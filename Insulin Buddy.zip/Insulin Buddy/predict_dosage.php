<?php
header('Content-Type: application/json');
include 'config.php';

// ------------------- 1. Read JSON POST -------------------
$input = json_decode(file_get_contents("php://input"), true);

$username = $input['username'] ?? '';
$current_glucose = $input['current_glucose'] ?? 0;
$carb_intake = $input['carb_intake'] ?? 0;
$activity_minutes = $input['activity_minutes'] ?? 0;
$stress_level = $input['stress_level'] ?? '';
$meal_type = $input['meal_type'] ?? '';
$notes = $input['notes'] ?? '';

// ------------------- 2. Validate username -------------------
if (empty($username)) {
    echo json_encode(["status" => "error", "message" => "Username required"]);
    exit;
}

// ------------------- 3. Fetch user profile -------------------
$sql = "SELECT contact, age, gender, isf, ic_ratio, target, weight, type_of_diabetes, diagnosis_year 
        FROM user_profile WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo json_encode(["status" => "error", "message" => "User not found"]);
    exit;
}
$userData = $result->fetch_assoc();

// ------------------- 4. Assign static values -------------------
$isf = $userData['isf'];
$ic_ratio = $userData['ic_ratio'];
$target = $userData['target'];
$age = $userData['age'];
$type_of_diabetes = strtolower($userData['type_of_diabetes']);

// ------------------- 5. Formula-based AI prediction -------------------
$correction_dose = ($current_glucose - $target) / $isf;
$meal_dose = $carb_intake / $ic_ratio;
$activity_adjustment = -($activity_minutes / 30);
$stress_adjustment = ($stress_level == "High") ? 1 : 0;

$aiDose = max(0, $correction_dose + $meal_dose + $activity_adjustment + $stress_adjustment);

// ------------------- 6. Warnings -------------------
$warnings = [];

if ($current_glucose < 70) {
    $warnings[] = "Low blood glucose detected! Eat 15g of fast-acting carbs immediately.";
}
if ($current_glucose > 150) {
    $warnings[] = "High blood glucose detected! Consider checking ketones if unwell.";
}
if ($age < 18) {
    $warnings[] = "Children require special care — consult your diabetes care team.";
} elseif ($age > 65) {
    $warnings[] = "Elderly patient — monitor for hypoglycemia.";
}
if ($type_of_diabetes == "type 1") {
    $warnings[] = "Type 1 Diabetes — Ensure basal insulin is taken regularly.";
} elseif ($type_of_diabetes == "type 2") {
    $warnings[] = "Type 2 Diabetes — Maintain consistent diet & exercise.";
}
if ($stress_level == "High") {
    $warnings[] = "High stress can increase glucose levels — consider relaxation techniques.";
}

// ------------------- 7. Store log -------------------
$log_date = date('Y-m-d');
$log_time = date('H:i:s');

$insert = "INSERT INTO insulin_logs 
    (username, log_date, log_time, current_glucose, carb_intake, activity_minutes, stress_level, meal_type, notes, ai_dose) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($insert);
$stmt->bind_param(
    "sssddisssd",
    $username, $log_date, $log_time, $current_glucose, $carb_intake, $activity_minutes, $stress_level, $meal_type, $notes, $aiDose
);
$stmt->execute();

// ------------------- 8. Return JSON -------------------
echo json_encode([
    "status" => "success",
    "static_data" => $userData,
    "dynamic_data" => [
        "current_glucose" => $current_glucose,
        "carb_intake" => $carb_intake,
        "activity_minutes" => $activity_minutes,
        "stress_level" => $stress_level,
        "meal_type" => $meal_type,
        "notes" => $notes
    ],
    "prediction" => [
        "ai_dose" => round($aiDose, 2),
        "correction" => round($correction_dose, 2),
        "meal_dose" => round($meal_dose, 2),
        "activity_adjustment" => round($activity_adjustment, 2),
        "stress_adjustment" => round($stress_adjustment, 2)
    ],
    "warnings" => $warnings
]);

$conn->close();
?>
