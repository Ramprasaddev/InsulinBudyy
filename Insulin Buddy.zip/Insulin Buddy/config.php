<?php
$host = "localhost";
$db_name = "insulinbuddy";
$username = "root";
$password = "123456";

// Create connection
$conn = mysqli_connect($host, $username, $password, $db_name);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
