<?php
include 'config.php';

header('Content-Type: application/json');

// Decode JSON input
$data = json_decode(file_get_contents("php://input"));

$username = trim($data->username ?? '');
$glucose_value = $data->glucose_value ?? null;
$note = $data->note ?? "";

// Basic validation
if (empty($username) || $glucose_value === null) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit;
}

if (!is_numeric($glucose_value) || $glucose_value < 0) {
    echo json_encode(["status" => "error", "message" => "Invalid glucose value"]);
    exit;
}

// 🧠 OPTIONAL: Check if user exists in your users table
$user_check = $conn->prepare("SELECT * FROM users WHERE username = ?");
$user_check->bind_param("s", $username);
$user_check->execute();
$user_result = $user_check->get_result();

if ($user_result->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "User not found"]);
    exit;
}
$user_check->close();

// Insert glucose data
$stmt = $conn->prepare("INSERT INTO glucose_level (username, glucose_value, note) VALUES (?, ?, ?)");
$stmt->bind_param("sds", $username, $glucose_value, $note);

if ($stmt->execute()) {
   
    echo json_encode(["status" => "success", "message" => "Glucose level recorded"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to insert glucose data"]);
}

$stmt->close();
$conn->close();
?>
