import pandas as pd
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel, Field
import joblib
import uvicorn
from typing import Literal
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.encoders import jsonable_encoder

# Load the machine learning model once when the application starts
try:
    model = joblib.load("rf_insulin_pipeline.joblib")
    print("Model loaded successfully.")
except FileNotFoundError:
    print("Error: 'rf_insulin_pipeline.joblib' file not found.")
    print("Please ensure the model file is in the same directory as app.py.")
    exit()

# Initialize the FastAPI application
app = FastAPI(title="InsulinBuddy RF Model", version="1.0")

# Custom handler for validation errors (422)
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    errors = []
    for err in exc.errors():
        loc = " -> ".join(str(x) for x in err.get("loc", []))
        msg = err.get("msg", "")
        t = err.get("type", "")
        errors.append({"field": loc, "error": msg, "type": t})
    
    return JSONResponse(
        status_code=422,
        content=jsonable_encoder({
            "status": "error",
            "message": "Validation failed",
            "details": errors
        }),
    )

# Define the input data model using Pydantic
class PredictIn(BaseModel):
    gender: Literal["Male", "Female"] = Field(..., description="Gender: Male or Female")
    age: int
    type_of_diabetes: Literal["Type1", "Type2"] = Field(..., description="Type of diabetes: Type1 or Type2")
    ICR: float
    ISR: float
    target_glucose: float
    current_glucose: float
    carbs: float
    activity: Literal["Low", "Moderate", "High"] = Field(..., description="Physical activity level: Low, Moderate, or High")
    time_of_day: Literal["Morning", "Lunch", "Evening", "Night"] = Field(..., description="Time of day: Morning, Lunch, Evening, or Night")

# Define the output data model to match the Android client
class PredictOut(BaseModel):
    status: str
    ai_dose: float
    carbs_dose: float
    correction: float
    message: str = None

@app.post("/predict", response_model=PredictOut)
def predict(x: PredictIn):
    """
    Makes a prediction of the recommended insulin dosage based on user data.
    """
    try:
        # Create a dictionary from the input data
        row = {
            "gender": x.gender,
            "age": x.age,
            "type_of_diabetes": x.type_of_diabetes,
            "ICR": x.ICR,
            "ISR": x.ISR,
            "target_glucose": x.target_glucose,
            "current_glucose": x.current_glucose,
            "carbs": x.carbs,
            "activity": x.activity,
            "time_of_day": x.time_of_day
        }

        # Calculate formula-based doses
        correction_dose = (x.current_glucose - x.target_glucose) / x.ISR
        carbs_dose_calc = x.carbs / x.ICR
        
        # Convert the dictionary into a pandas DataFrame
        input_df = pd.DataFrame([row])
        
        # Make the prediction using the DataFrame
        prediction = model.predict(input_df)[0]
        
        # Ensure the prediction is not negative and round it
        ai_dose = round(max(0.0, prediction), 1)

        # Return all calculated and predicted values
        return {
            "status": "success", 
            "ai_dose": ai_dose, 
            "carbs_dose": round(carbs_dose_calc, 2),
            "correction": round(correction_dose, 2),
            "message": "Prediction successful."
        }

    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail={
                "status": "error",
                "ai_dose": 0.0,
                "carbs_dose": 0.0,
                "correction": 0.0,
                "message": f"An error occurred: {str(e)}"
            }
        )

if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8001, reload=False)
